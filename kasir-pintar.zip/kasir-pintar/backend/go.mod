module kasir

go 1.22
