package main

import (
	"encoding/json"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
	_ "time/tzdata"
)

type Product struct {
	ID      int    `json:"id"`
	Barcode string `json:"barcode"`
	Name    string `json:"name"`
	Price   int64  `json:"price"`
	Stock   int    `json:"stock"`
}

type Item struct {
	Barcode  string `json:"barcode"`
	Name     string `json:"name"`
	Price    int64  `json:"price"`
	Qty      int    `json:"qty"`
	Subtotal int64  `json:"subtotal"`
}

type Transaction struct {
	ID     int       `json:"id"`
	Time   time.Time `json:"time"`
	Items  []Item    `json:"items"`
	Total  int64     `json:"total"`
	Paid   int64     `json:"paid"`
	Change int64     `json:"change"`
}

type Data struct {
	Products      []Product     `json:"products"`
	Transactions  []Transaction `json:"transactions"`
	NextProductID int           `json:"nextProductId"`
	NextTxID      int           `json:"nextTxId"`
}

type Store struct {
	mu   sync.Mutex
	path string
	data Data
}

var (
	store *Store
	loc   *time.Location
)

func loadStore(path string) *Store {
	s := &Store{path: path, data: Data{NextProductID: 1, NextTxID: 1}}
	if b, err := os.ReadFile(path); err == nil {
		if err := json.Unmarshal(b, &s.data); err != nil {
			log.Fatal("db rusak: ", err)
		}
	}
	return s
}

func (s *Store) save() error {
	b, err := json.MarshalIndent(s.data, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, s.path)
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, code int, msg string) {
	writeJSON(w, code, map[string]string{"error": msg})
}

func listProducts(w http.ResponseWriter, r *http.Request) {
	store.mu.Lock()
	defer store.mu.Unlock()
	out := append([]Product{}, store.data.Products...)
	writeJSON(w, 200, out)
}

func productByBarcode(w http.ResponseWriter, r *http.Request) {
	code := r.PathValue("code")
	store.mu.Lock()
	defer store.mu.Unlock()
	for _, p := range store.data.Products {
		if p.Barcode == code {
			writeJSON(w, 200, p)
			return
		}
	}
	writeErr(w, 404, "Barang dengan barcode "+code+" tidak ditemukan")
}

func upsertProduct(w http.ResponseWriter, r *http.Request) {
	var in Product
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
		writeErr(w, 400, "JSON tidak valid")
		return
	}
	in.Barcode, in.Name = strings.TrimSpace(in.Barcode), strings.TrimSpace(in.Name)
	if in.Barcode == "" || in.Name == "" || in.Price < 0 || in.Stock < 0 {
		writeErr(w, 400, "Barcode, nama, harga (>=0) dan stok (>=0) wajib diisi")
		return
	}
	store.mu.Lock()
	defer store.mu.Unlock()
	found := false
	for i := range store.data.Products { // loop: cari barang, update bila sudah ada
		if store.data.Products[i].Barcode == in.Barcode {
			in.ID = store.data.Products[i].ID
			store.data.Products[i] = in
			found = true
			break
		}
	}
	if !found {
		in.ID = store.data.NextProductID
		store.data.NextProductID++
		store.data.Products = append(store.data.Products, in)
	}
	if err := store.save(); err != nil {
		writeErr(w, 500, "Gagal menyimpan")
		return
	}
	writeJSON(w, 200, in)
}

func deleteProduct(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.Atoi(r.PathValue("id"))
	store.mu.Lock()
	defer store.mu.Unlock()
	for i, p := range store.data.Products {
		if p.ID == id {
			store.data.Products = append(store.data.Products[:i], store.data.Products[i+1:]...)
			store.save()
			writeJSON(w, 200, map[string]bool{"ok": true})
			return
		}
	}
	writeErr(w, 404, "Barang tidak ditemukan")
}

type checkoutReq struct {
	Items []struct {
		Barcode string `json:"barcode"`
		Qty     int    `json:"qty"`
	} `json:"items"`
	Paid int64 `json:"paid"`
}

func createTransaction(w http.ResponseWriter, r *http.Request) {
	var in checkoutReq
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil || len(in.Items) == 0 {
		writeErr(w, 400, "Keranjang kosong atau JSON tidak valid")
		return
	}
	store.mu.Lock()
	defer store.mu.Unlock()

	// Harga SELALU dihitung server dari database (bukan dari klien).
	need := map[int]int{} // index produk -> total qty
	var items []Item
	var total int64
	for _, it := range in.Items { // loop 1: validasi & hitung total
		idx := -1
		for i, p := range store.data.Products {
			if p.Barcode == it.Barcode {
				idx = i
				break
			}
		}
		if idx < 0 || it.Qty <= 0 {
			writeErr(w, 400, "Barang/qty tidak valid: "+it.Barcode)
			return
		}
		p := store.data.Products[idx]
		need[idx] += it.Qty
		if need[idx] > p.Stock {
			writeErr(w, 400, "Stok "+p.Name+" tidak cukup (sisa "+strconv.Itoa(p.Stock)+")")
			return
		}
		sub := p.Price * int64(it.Qty)
		total += sub
		items = append(items, Item{p.Barcode, p.Name, p.Price, it.Qty, sub})
	}
	if in.Paid < total {
		writeErr(w, 400, "Uang pelanggan kurang "+strconv.FormatInt(total-in.Paid, 10))
		return
	}
	for idx, q := range need { // loop 2: kurangi stok
		store.data.Products[idx].Stock -= q
	}
	tx := Transaction{
		ID: store.data.NextTxID, Time: time.Now().In(loc), Items: items,
		Total: total, Paid: in.Paid, Change: in.Paid - total,
	}
	store.data.NextTxID++
	store.data.Transactions = append(store.data.Transactions, tx)
	if err := store.save(); err != nil {
		writeErr(w, 500, "Gagal menyimpan transaksi")
		return
	}
	writeJSON(w, 201, tx)
}

func listTransactions(w http.ResponseWriter, r *http.Request) {
	month := r.URL.Query().Get("month") // contoh: 2026-11
	store.mu.Lock()
	defer store.mu.Unlock()
	out := []Transaction{}
	for _, t := range store.data.Transactions {
		if month == "" || t.Time.In(loc).Format("2006-01") == month {
			out = append(out, t)
		}
	}
	writeJSON(w, 200, out)
}

type MonthReport struct {
	Month   string `json:"month"`
	Count   int    `json:"count"`
	Revenue int64  `json:"revenue"`
}

func monthlyReport(w http.ResponseWriter, r *http.Request) {
	store.mu.Lock()
	defer store.mu.Unlock()
	agg := map[string]*MonthReport{}
	for _, t := range store.data.Transactions { // loop: kelompokkan per bulan
		key := t.Time.In(loc).Format("2006-01")
		if agg[key] == nil {
			agg[key] = &MonthReport{Month: key}
		}
		agg[key].Count++
		agg[key].Revenue += t.Total
	}
	current := time.Now().In(loc).Format("2006-01")
	if agg[current] == nil {
		agg[current] = &MonthReport{Month: current}
	}
	months := make([]MonthReport, 0, len(agg))
	for _, m := range agg {
		months = append(months, *m)
	}
	sort.Slice(months, func(i, j int) bool { return months[i].Month > months[j].Month })
	writeJSON(w, 200, map[string]any{"current": current, "months": months})
}

func main() {
	var err error
	if loc, err = time.LoadLocation("Asia/Jakarta"); err != nil {
		loc = time.UTC
	}
	dbPath := os.Getenv("DATA_FILE")
	if dbPath == "" {
		dbPath = "data/db.json"
	}
	os.MkdirAll(filepath.Dir(dbPath), 0o755)
	store = loadStore(dbPath)

	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/health", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, 200, map[string]bool{"ok": true}) })
	mux.HandleFunc("GET /api/products", listProducts)
	mux.HandleFunc("GET /api/products/barcode/{code}", productByBarcode)
	mux.HandleFunc("POST /api/products", upsertProduct)
	mux.HandleFunc("DELETE /api/products/{id}", deleteProduct)
	mux.HandleFunc("POST /api/transactions", createTransaction)
	mux.HandleFunc("GET /api/transactions", listTransactions)
	mux.HandleFunc("GET /api/reports/monthly", monthlyReport)

	port := os.Getenv("GO_PORT")
	if port == "" {
		port = "8081"
	}
	log.Println("API Golang di :" + port)
	log.Fatal(http.ListenAndServe("127.0.0.1:"+port, mux))
}
