#!/bin/sh
# Menjalankan API Golang (background) + gateway Node.js (foreground)
if [ -x ./kasir-api ]; then
  ./kasir-api &
else
  (cd backend && go run .) &
fi
exec node server.js
