// Scan via kamera memakai BarcodeDetector (Chrome/Edge/Android).
// Scanner USB/Bluetooth tidak perlu kode ini: ia bekerja seperti keyboard + Enter.
export async function startCamera(video, onCode) {
  if (!('BarcodeDetector' in window)) {
    throw new Error('Browser belum mendukung scan kamera. Pakai scanner USB atau ketik manual.');
  }
  const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
  video.srcObject = stream;
  video.hidden = false;
  await video.play();

  const detector = new BarcodeDetector();
  let active = true, last = '', lastAt = 0;

  (async function loop() {
    while (active) { // looping deteksi tiap 250 ms
      try {
        const codes = await detector.detect(video);
        const now = Date.now();
        if (codes[0] && (codes[0].rawValue !== last || now - lastAt > 2000)) {
          last = codes[0].rawValue; lastAt = now;
          onCode(last);
        }
      } catch { /* abaikan frame gagal */ }
      await new Promise((r) => setTimeout(r, 250));
    }
  })();

  return () => {
    active = false;
    stream.getTracks().forEach((t) => t.stop());
    video.srcObject = null;
    video.hidden = true;
  };
}
