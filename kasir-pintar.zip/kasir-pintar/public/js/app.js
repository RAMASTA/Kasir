import { api } from './api.js';
import { startCamera } from './scanner.js';

const $ = (s) => document.querySelector(s);
const rp = (n) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(n || 0);
const el = (tag, text, cls) => { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; if (cls) e.className = cls; return e; };

let cart = [];
let stopCam = null;

// ---------- Tab ----------
document.querySelectorAll('nav button').forEach((b) => {
  b.onclick = () => {
    document.querySelectorAll('nav button, .tab').forEach((x) => x.classList.remove('active'));
    b.classList.add('active');
    $('#' + b.dataset.tab).classList.add('active');
    if (b.dataset.tab === 'produk') loadProducts();
    if (b.dataset.tab === 'laporan') loadReport();
    if (b.dataset.tab === 'kasir') $('#barcode').focus();
  };
});

// ---------- Kasir ----------
function msg(text, err = false) { const m = $('#msg'); m.textContent = text; m.className = 'msg' + (err ? ' err' : ''); }
const total = () => cart.reduce((sum, it) => sum + it.price * it.qty, 0);

function renderCart() {
  const tb = $('#cart');
  tb.replaceChildren();
  cart.forEach((it, i) => { // looping isi keranjang
    const tr = el('tr');
    tr.append(el('td', it.name), el('td', rp(it.price)));
    const qtyCell = el('td');
    const qty = el('input'); qty.type = 'number'; qty.min = 1; qty.value = it.qty; qty.className = 'qty';
    qty.onchange = () => { it.qty = Math.max(1, parseInt(qty.value) || 1); renderCart(); };
    qtyCell.append(qty);
    const del = el('button', '✕', 'danger');
    del.onclick = () => { cart.splice(i, 1); renderCart(); };
    const delCell = el('td'); delCell.append(del);
    tr.append(qtyCell, el('td', rp(it.price * it.qty)), delCell);
    tb.append(tr);
  });
  updatePay();
}

function updatePay() {
  const t = total();
  const paid = Number($('#paid').value) || 0;
  const diff = paid - t;
  $('#total').textContent = rp(t);
  $('#change').textContent = rp(Math.max(diff, 0));
  $('#change').classList.toggle('short', paid > 0 && diff < 0);
  $('#btnPay').disabled = cart.length === 0 || paid < t;
}

async function addByBarcode(raw) {
  const code = raw.trim();
  if (!code) return;
  try {
    const p = await api.byBarcode(code);
    const existing = cart.find((c) => c.barcode === p.barcode);
    if (existing) existing.qty++; else cart.push({ barcode: p.barcode, name: p.name, price: p.price, qty: 1 });
    msg(`${p.name} — ${rp(p.price)}`);
    renderCart();
  } catch (e) { msg(e.message, true); }
}

$('#barcode').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { addByBarcode(e.target.value); e.target.value = ''; }
});
$('#paid').addEventListener('input', updatePay);
$('#btnClear').onclick = () => { cart = []; $('#paid').value = ''; $('#receipt').textContent = ''; renderCart(); $('#barcode').focus(); };

$('#btnCam').onclick = async () => {
  if (stopCam) { stopCam(); stopCam = null; $('#btnCam').textContent = '📷 Kamera'; return; }
  try {
    stopCam = await startCamera($('#cam'), addByBarcode);
    $('#btnCam').textContent = '⏹ Stop';
  } catch (e) { msg(e.message, true); }
};

$('#btnPay').onclick = async () => {
  try {
    const tx = await api.checkout(cart.map(({ barcode, qty }) => ({ barcode, qty })), Number($('#paid').value));
    const lines = ['KASIR PINTAR', new Date(tx.time).toLocaleString('id-ID'), `No. ${tx.id}`, '----------------'];
    tx.items.forEach((it) => lines.push(`${it.name} x${it.qty}  ${rp(it.subtotal)}`)); // looping struk
    lines.push('----------------', `Total    ${rp(tx.total)}`, `Bayar    ${rp(tx.paid)}`, `Kembali  ${rp(tx.change)}`);
    $('#receipt').textContent = lines.join('\n');
    cart = []; $('#paid').value = ''; renderCart();
    msg(`Transaksi berhasil. Kembalian ${rp(tx.change)}`);
  } catch (e) { msg(e.message, true); }
  $('#barcode').focus();
};

// ---------- Produk ----------
async function loadProducts() {
  const list = await api.products();
  const tb = $('#plist');
  tb.replaceChildren();
  list.forEach((p) => {
    const tr = el('tr');
    tr.append(el('td', p.barcode), el('td', p.name), el('td', rp(p.price)), el('td', String(p.stock)));
    const edit = el('button', 'Ubah');
    edit.onclick = () => { const f = $('#pform'); f.barcode.value = p.barcode; f.name.value = p.name; f.price.value = p.price; f.stock.value = p.stock; };
    const del = el('button', 'Hapus', 'danger');
    del.onclick = async () => { if (confirm(`Hapus ${p.name}?`)) { await api.deleteProduct(p.id); loadProducts(); } };
    const act = el('td'); act.append(edit, ' ', del);
    tr.append(act);
    tb.append(tr);
  });
}

$('#pform').onsubmit = async (e) => {
  e.preventDefault();
  const f = e.target;
  try {
    await api.saveProduct({ barcode: f.barcode.value, name: f.name.value, price: Number(f.price.value), stock: Number(f.stock.value) });
    f.reset(); loadProducts();
  } catch (err) { alert(err.message); }
};

// ---------- Laporan ----------
async function loadReport() {
  const { current, months } = await api.monthly();
  const tb = $('#mlist');
  tb.replaceChildren();
  months.forEach((m) => { // looping tiap bulan
    const tr = el('tr');
    tr.append(el('td', m.month), el('td', String(m.count)), el('td', rp(m.revenue)));
    tb.append(tr);
    if (m.month === current) { $('#curMonth').textContent = m.month; $('#curRevenue').textContent = rp(m.revenue); }
  });
}

renderCart();
