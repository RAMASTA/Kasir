# 🧾 Kasir Pintar

Web app kasir (POS): scan barang → harga muncul → input uang pelanggan → kembalian otomatis → laporan pendapatan per bulan.

**Stack:** JavaScript modern (ES Modules) · Node.js (gateway + file statis) · Golang (REST API, penyimpanan JSON).
Tanpa dependensi npm dan tanpa dependensi Go eksternal, jadi langsung jalan.

## Struktur
```
kasir-pintar/
├── backend/            # API Golang
│   ├── go.mod
│   └── main.go         # produk, transaksi, laporan bulanan
├── public/             # Frontend
│   ├── index.html
│   ├── css/style.css
│   └── js/{app,api,scanner}.js
├── server.js           # Node.js: sajikan public/ + proxy /api ke Go
├── start.sh            # jalankan Go + Node bersamaan
├── Dockerfile          # deploy 1 container
├── package.json
└── .gitignore
```

## Jalankan lokal
Prasyarat: Node.js 18+ dan Go 1.22+.
```bash
sh start.sh          # atau: npm start
```
Buka http://localhost:3000. Data tersimpan di `backend/data/db.json`.

## Alur pakai
1. Tab **Produk** → tambah barang (barcode, nama, harga, stok).
2. Tab **Kasir** → scan barcode (scanner USB = ketik + Enter, atau tombol Kamera) → barang masuk keranjang.
3. Isi **Uang pelanggan** → kembalian tampil → **Bayar**.
4. Tab **Laporan** → pendapatan bulan ini dan bulan-bulan sebelumnya.

## Deploy
- **VPS / Railway / Render / Fly.io:** pakai `Dockerfile` (mount volume ke `/app/data` agar data tidak hilang).
- **Hosting biasa (cPanel/shared):** biasanya tidak bisa menjalankan Go; gunakan VPS atau Docker.
- **GitHub Pages:** hanya untuk file statis, tidak bisa menjalankan Node/Go.

## Langkah pengembangan berikutnya
1. Login kasir/admin (JWT atau session) + peran.
2. Pindah penyimpanan ke SQLite/PostgreSQL bila transaksi sudah banyak.
3. Cetak struk thermal (ESC/POS atau `window.print`).
4. Diskon, pajak, metode bayar (tunai/QRIS).
5. Laporan harian, barang terlaris, ekspor CSV/Excel.
6. Peringatan stok menipis, retur/void transaksi.
7. Mode offline (PWA) dengan antrean sinkronisasi.
8. HTTPS + backup otomatis `db.json`.
