async function req(url, opts = {}) {
  const res = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Error ${res.status}`);
  return data;
}

export const api = {
  products: () => req('/api/products'),
  byBarcode: (code) => req(`/api/products/barcode/${encodeURIComponent(code)}`),
  saveProduct: (p) => req('/api/products', { method: 'POST', body: JSON.stringify(p) }),
  deleteProduct: (id) => req(`/api/products/${id}`, { method: 'DELETE' }),
  checkout: (items, paid) => req('/api/transactions', { method: 'POST', body: JSON.stringify({ items, paid }) }),
  monthly: () => req('/api/reports/monthly'),
};
